//
//  CuentaViewController.swift
//  Bolo Go
//
//  Created by Luis Alberto Fernández Castro on 4/28/19.
//  Copyright © 2019 01001100. All rights reserved.
//

import UIKit

class CuentaViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nipTextField: UITextField!
    @IBOutlet weak var `switch`: UISwitch!
    @IBOutlet weak var nipIncorrectoLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nipTextField.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }

    @IBAction func kidsModeOnOff(_ sender: Any) {
        `switch`.setOn(!`switch`.isOn, animated: false)
        if `switch`.isOn {
            if nipTextField.text == "1111" {
                print("currentlyOnKidsMode")
                `switch`.setOn(true, animated: false)
                nipIncorrectoLabel.isHidden = true
            } else {
                nipIncorrectoLabel.isHidden = false
                `switch`.setOn(false, animated: false)
                print("currentlyOnNormalMode")
            }
        } else {
            if nipTextField.text == "1111" {
                print("currentlyOnNormalMode")
                `switch`.setOn(false, animated: false)
                nipIncorrectoLabel.isHidden = true
            } else {
                nipIncorrectoLabel.isHidden = false
                `switch`.setOn(true, animated: false)
                print("currentlyOnKidsMode")
            }
        }
    }
    
}
