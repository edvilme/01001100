//
//  CartaSantaViewController.swift
//  Bolo Go
//
//  Created by Luis Alberto Fernández Castro on 4/28/19.
//  Copyright © 2019 01001100. All rights reserved.
//

import UIKit

class CartaSantaViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var juguetesArray = ["Lego Star Wars 300+ piezas", "Barbie Versión 678", "Hot Wheels", "Turbo Max Steel 3"]
    @IBOutlet weak var cartaTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cartaTableView.delegate = self
        cartaTableView.dataSource = self
        cartaTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return juguetesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = juguetesArray[indexPath.row]
        return cell
    }
    
    @IBAction func agregarArtículos(_ sender: Any) {
        juguetesArray.append("Figura de acción Avengers: Endgame")
        cartaTableView.reloadData()
    }
    
}
