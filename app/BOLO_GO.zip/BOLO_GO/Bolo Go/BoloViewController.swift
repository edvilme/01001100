//
//  ViewController.swift
//  Bolo Go
//
//  Created by Luis Alberto Fernández Castro on 4/27/19.
//  Copyright © 2019 01001100. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class BoloViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    let updateQueue = DispatchQueue(label: "\(Bundle.main.bundleIdentifier!).serialSCNQueue")
    var boloArray = [SCNNode]()
    var counter = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.autoenablesDefaultLighting = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if ARWorldTrackingConfiguration.isSupported {
        
            // Create a session configuration
            guard let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil) else {
                fatalError("Missing expected asset catalog resources.")
            }
            let configuration = ARWorldTrackingConfiguration()
            configuration.detectionImages = referenceImages
            configuration.planeDetection = .horizontal
            sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        } else {
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let imageAnchor = anchor as? ARImageAnchor else { return }
        updateQueue.async {
            let referenceImage = imageAnchor.referenceImage
            let plane = SCNPlane(width: referenceImage.physicalSize.width, height: referenceImage.physicalSize.height)
            let planeNode = SCNNode(geometry: plane)
            planeNode.opacity = 0.25
            planeNode.eulerAngles.x = -.pi / 2
            node.addChildNode(planeNode)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if boloArray.count < 1 {
            sceneView.debugOptions = []
            if let touch = touches.first {
                let touchLocation = touch.location(in: sceneView)
                let results = sceneView.hitTest(touchLocation, types: .existingPlaneUsingExtent)
                if let hitResults = results.first {
                    let boloScene = SCNScene(named: "art.scnassets/scene.scn")!
                    if let boloNode = boloScene.rootNode.childNode(withName: "Scene", recursively: true) {
                        boloNode.position = SCNVector3(x: hitResults.worldTransform.columns.3.x, y: hitResults.worldTransform.columns.3.y, z: hitResults.worldTransform.columns.3.z)
                        roll(bolo: boloNode)
                        sceneView.scene.rootNode.addChildNode(boloNode)
                        boloArray.append(boloNode)
                    }
                }
            }
        } else {
            roll(bolo: boloArray[0])
        }
    }
    
    func roll(bolo: SCNNode) {
        if counter % 2 == 0 {
            bolo.runAction(SCNAction.rotateBy(x: 0, y: CGFloat(-Float.pi * 2), z: 0, duration: 0.5))
            counter += 1
        } else {
            bolo.runAction(SCNAction.rotateBy(x: 0, y: CGFloat(Float.pi * 2), z: 0, duration: 0.5))
            counter += 1
        }
    }
    
}
